<template>
<div>
	题目列表
</div>
</template>
<script>
	export default{ // es6的导出对象的写法
	}
</script>
<style scoped>
</style>
