var sysConfig = {
    xcApiUrlPre: '/api',
    //xcApiUrlPre: '',
    xcApiUrl: 'http://api.xuecheng.com',
    imgUrl:'http://img.xuecheng.com/',
    videoUrl:'http://video.xuecheng.com',
    openAuthenticate:false,
    openAuthorize:false
}

module.exports = sysConfig
