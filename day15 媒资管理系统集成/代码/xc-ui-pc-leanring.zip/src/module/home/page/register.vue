<template>
	<div >
	注册
	</div>
</template>
<script>
	export default{

	}
</script>
<style scoped>

</style>
