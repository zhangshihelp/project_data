<template>
<div>
	添加题目
</div>
</template>
<script>
	export default{ // es6的导出对象的写法
	}
</script>
<style scoped>
</style>
