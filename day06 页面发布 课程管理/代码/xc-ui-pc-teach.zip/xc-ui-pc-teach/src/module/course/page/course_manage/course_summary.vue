<template>
  <div>
课程首页
  </div>
</template>
<script>

</script>
<style>

</style>
