package com.xuecheng.framework.client;


public class XcServiceList {
    public static final String XC_GOVERN_CENTER = "xc-govern-center";
    public static final String XC_SERVICE_PORTALVIEW = "xc-service-portalview";
    public static final String XC_SERVICE_SEARCH = "xc-service-search";
    public static final String XC_SERVICE_MANAGE_COURSE = "xc-service-manage-course";
    public static final String XC_SERVICE_MANAGE_MEDIA = "xc-service-manage-media";
    public static final String XC_SERVICE_MANAGE_CMS = "xc-service-manage-cms";
    public static final String XC_SERVICE_UCENTER = "xc-service-ucenter";
    public static final String XC_SERVICE_UCENTER_AUTH = "xc-service-ucenter-auth";
    public static final String XC_SERVICE_UCENTER_JWT = "xc-service-ucenter-jwt";
    public static final String XC_SERVICE_BASE_FILESYSTEM = "xc-service-base-filesystem";
    public static final String XC_GOVERN_GATEWAY = "xc-govern-gateway";
    public static final String XC_SERVICE_BASE_ID = "xc-service-base-id";
    public static final String XC_SERVICE_MANAGE_ORDER = "xc-service-manage-order";
    public static final String XC_SERVICE_LEARNING = "xc-service-learning";

}
